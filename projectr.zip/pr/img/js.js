
const firstname=document.getElementById("firstname");
const lastname=document.getElementById("lastname");
function validateForm(){
  if(allLetter(firstname)){

  }
  if(allLetter2(lastname)){

  }
  if(firstname.value.length<2 || firstname.value.length>21){
    alert("First Name length should be more than 2 and less than 21");
    firstname.focus();
    return false;
  }
  else if(lastname.value.length<2 || lastname.value.length>21){
    alert("Last Name length should be more than 2 and less than 21");
    lastname.focus();
    return false;
  }
}
function allLetter(firstname){
  const al = /^[A-Za-z]+$/;
  if(firstname.value.match(al))
  {
    return true;
  }
  else
  {
    alert('First Name should be only alphabet');
    firstname.focus();
    return false;
  }
}
function allLetter2(lastname){
  const al = /^[A-Za-z]+$/;
  if(lastname.value.match(al))
  {
    return true;
  }
  else
  {
    alert('Last Name should be only alphabet');
    lastname.focus();
    return false;
  }
}

const cities = {
  Kazakhstan: ["Astana","Almaty","Shymkent"],
  US: ["New York","Chicago","San Diego"],
  UK: ["London","Manchester","Birmingham"]
}
function make(a) {
  if(a.length==0) document.getElementById("city").innerHTML = "<option></option>";
  else {
    var citiesOptions = "";
    for(id in cities[a]) {
      citiesOptions+="<option>"+cities[a][id]+"</option>";
    }
    document.getElementById("city").innerHTML = citiesOptions;
  }
}
function dis() {
  var country = document.getElementById("country").value;
  const city = document.getElementById("city").value;
  alert(country+"\n"+city);
}

function check() {
  var selectElement = document.getElementById("symptoms");
  var selectedSymptoms = [];
  for (var i = 0; i < selectElement.options.length; i++) {
    if (selectElement.options[i].selected) {
      selectedSymptoms.push(selectElement.options[i].value);
    }
  }

  const diseases = {
    "Frequent urination": {
      name: "Diabetes mellitus",
      treatment: "Monitor blood sugar levels, take prescribed medications, maintain a healthy diet and exercise regularly."
    },
    "Memory loss": {
      name: "Alzheimer's disease",
      treatment: "Alzheimer's disease has no known cure, but there are therapies and interventions that can help control the symptoms and enhance quality of life." +
          "We advise you to speak with a specialist."
    },
    "Watery, loose stools": {
      name: "Diarrhea",
      treatment: "Appendectomy surgery is typically performed to remove the inflamed appendix."
    },
    "Eye irritation": {
      name: "Allergies",
      treatment: "Eliminating or avoiding the source is the simplest and best strategy to treat allergies."
    },
    "Headache": {
      name: "Migraine or Tension headache",
      treatment: "Sleeping, or at least relaxing in a dimly lit space." +
          " Taking getaways from challenging circumstances"
    },
    "Mood swings": {
      name: "Mood disorders",
      treatment: "Treatment may involve therapy, medications, lifestyle changes, and support from mental health professionals."
    },
    "fever (100° F)": {
      name: "Common cold or Bronchitis",
      treatment: "Increased rest is advised, and refrain from exercise until symptoms subside.\n" +
          "Drink a lot of liquids that are clear, such water or tea."
    },
    "Joint pain": {
      name: "Autoimmune disorders",
      treatment: "Treatment depends on the specific autoimmune disorder and may involve medications, physical therapy, lifestyle modifications, and other interventions."
    },
    "Swelling": {
      name: "Autoimmune disorders",
      treatment: "Treatment depends on the underlying autoimmune disorder and may involve medications, lifestyle changes, and managing inflammation."
    },
    "Fever": {
      name: "Influenza or COVID-19",
      treatment: "For mild cases, rest, stay hydrated, and use over-the-counter fever reducers. Seek medical attention for severe symptoms or if you suspect COVID-19."
    },
    "Redness, itching, tearing, burning sensation": {
      name: "Conjunctivitis (“pink eye“)",
      treatment: "Wash your hands often to avoid transferring an infection to your other eye or to others.\n" +
          "Avoid rubbing your eyes.\n" +
          "To remove any crusting, use a cool, moist towel."
    },
    "Cough": {
      name: "Common cold",
      treatment: "You should seek medical attention if something is making you uncomfortable.\n" +
          "\n" +"<br><br>"+
          "Get medical help right away if you have:\n" +
          "\n" +
          "102°F or higher fever, persistent cough, particularly when accompanied by a high fever (which may indicate pneumonia), persistent sore throat, especially if a runny nose does not develop (which may indicate strep infection), or any cold lasting longer than 10 days.\n"
    }
  };

  var matchedDiseases = [];
  for (var s in diseases) {
    if (selectedSymptoms.includes(s)) {
      matchedDiseases.push(diseases[s]);
    }
  }

  var result = document.getElementById("result");
  if (matchedDiseases.length > 0) {
    var info = "";
    matchedDiseases.forEach(function(disease) {
      info += "<strong>" + disease.name + "</strong> "+ "<br>"+"</strong>"+"Treatment for this:"+"</strong>" +" "+ disease.treatment+"</strong>" + "<br><br>";
    });
    result.innerHTML = "Possible disease(s):<br>" + info;
  } else {
    result.innerHTML = "Sorry, no such as diseases found.";
  }
}
function showClinics() {
  window.open("https://www.gov.uk/government/publications/kazakhstan-list-of-medical-facilities/list-of-medical-facilitiespractitioners-in-kazakhstan--2#astana");
}
function showDiagnostics(){
 window.open("  window.open(\"https://www.gov.uk/government/publications/kazakhstan-list-of-medical-facilities/list-of-medical-facilitiespractitioners-in-kazakhstan--2#astana\");\n")
}
function showSymptoms(){
  window.open("https://uhs.princeton.edu/health-resources/common-illnesses")
}
function showDiseases(){
  window.open("https://www.nhsinform.scot/illnesses-and-conditions/a-to-z")
}
